# Stable Branch
Future release builds are built on this branch.

# Build Commands
* electron-packager . --platform=win32 --arch=x64
* sudo ./node_modules/.bin/electron-packager . --platform=linux --arch=x64

# Requirements
* Windows/Linux
* Node.js 6.10.0+

# Required Node Modules
* electron
* electron-packager

# Todo
* Add config file (done)
* Add log file for created passwords (done)
* Make it pretty (white theme is ugly)

# FAQ
Q. Do you support Mac?
A. I do not own a Mac and have no interest atm.
